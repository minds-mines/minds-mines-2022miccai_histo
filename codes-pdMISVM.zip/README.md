Language: Julia version 1.6.

- This projects contains 4 files:
1. pdMISVMClassifier.jl: The implementation of primal-dual Multi-Instance Support Vector Machine (pdMISVM). 
2. KernelpdMISVMClassifier.jl: The implementation of kerneled version of pdMISVM.
3. pdmisvm_test.jl: The test code for pdMISVM which includes toy dataset. This tests (1) whether we update each variable where the derivative is zero, and (2) whether the objective is decreasing at each update.
4. Project.toml: This specifies the required packages to run the code.

- How to run:
1. Creates a Julia session.
2. Creates a Julia project and install the required packages listed in ./Project.toml.
3. Run 'julia include("./pdmisvm_test.jl")'.